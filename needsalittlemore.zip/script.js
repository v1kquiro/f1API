// F1API base URL
const apiUrl = 'https://api.openf1.org/v1/car_data';

// Function to fetch and display F1 data
async function getF1() {
    const f1Input = document.getElementById('f1nInput').value.toLowerCase(); // Get input value
    const f1Container = document.getElementById('f1Container');
    const errorMessage = document.getElementById('errorMessage');

    // Clear previous data and errors
    f1Container.style.display = 'none';
    errorMessage.textContent = '';

    if (!f1Input) {
        errorMessage.textContent = 'Please enter a F1 driver name .';
        return;
    }

    try {
        // Fetch F1 data from F1API
        const response = await fetch(`${apiUrl}${f1Input}`);
        if (!response.ok) {
            throw new Error('F1 Driver not found');
        }

        const data = await response.json();
        displayf1(data); // Call function to display F1 details
    } catch (error) {
        errorMessage.textContent = `Error: ${error.message}`;
    }
}

// Function to display Pokémon data
function displayf1(data) {
    const f1Name = document.getElementById('f1Name');
    const f1Image = document.getElementById('f1Image');
    const f1Type = document.getElementById('f1Type');
    const f1Height = document.getElementById('f1Height');
    const f1Weight = document.getElementById('f1Weight');
    const f1Container = document.getElementById('f1Container');

    // Set the Pokémon name, image, type, height, and weight
    f1Name.textContent = capitalizeFirstLetter(data.name);
    f1Image.src = data.sprites.front_default;
    f1Type.textContent = data.types.map(type => capitalizeFirstLetter(type.type.name)).join(', ');
    f1Height.textContent = `${data.height / 10} m`; // Convert to meters
   f1Weight.textContent = `${data.weight / 10} kg`; // Convert to kilograms

    // Display the Pokémon container
    f1Container.style.display = 'block';
}

// Helper function to capitalize the first letter of a string
function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
}
